/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cakeproject;

/**
 * *Tyler Young
 * ID 890090583
 * Lab Section: 1
 * Assignment: 4
 * Submission Time; 6:11pm
 * @author tyoun66
 * @author tyoun66
 */
public class WeddingCake extends Cake 
{
    public String bridesFirstName;
    public String groomsFirstName;

    public WeddingCake(String Flav, int Tier, double Price, String bridgesFirst, String groomsFirst) {
        super(Flav, Tier, Price);
        bridesFirstName = bridgesFirst;
        groomsFirstName = groomsFirst;
    }
    @Override
    public void printCard() {
        System.out.printf("\nHappy Wedding to %s and %s\n", bridesFirstName, groomsFirstName);
        super.printCard();
    }
}
