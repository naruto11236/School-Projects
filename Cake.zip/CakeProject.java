/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cakeproject;

/**
 * *Tyler Young
 * ID 890090583
 * Lab Section: 1
 * Assignment: 4
 * Submission Time; 6:11pm
 * @author tyoun66
 * @author tyoun66
 */
public class CakeProject {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        WeddingCake wedCk = new WeddingCake("chocolate", 3, 355.0, "Sarah", "John");
        wedCk.printInvoice();
        wedCk.printCard();
        System.out.println();
        BirthDayCake bdCk = new BirthDayCake("vanilla", 1, 20.0, "Alan", 15);
        bdCk.printInvoice();
        bdCk.printCard();
    }
    
}
