/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cakeproject;

import java.time.LocalDate;

/**
 *Tyler Young
 * ID 890090583
 * Lab Section: 1
 * Assignment: 4
 * Submission Time; 6:11pm
 * @author tyoun66
 */
public class Cake {
    public String flavor;
    public int tiers; 
    public double price;
    public Cake(String Flav, int Tier, double Price) {
        flavor = Flav;
        tiers = Tier;
        price = Price;
        
    }
    public void printInvoice() {
        System.out.printf("A %d tier %s cake. The price is $%.1f. Issued on: ", tiers, flavor, price);
        System.out.print(LocalDate.now());
    }
    public void printCard() {
        System.out.println("Thank you for choosing us!");
    }
    
     
}
