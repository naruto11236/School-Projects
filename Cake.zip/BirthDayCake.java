/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cakeproject;

/**
 * *Tyler Young
 * ID 890090583
 * Lab Section: 1
 * Assignment: 4
 * Submission Time; 6:11pm
 * @author tyoun66
 * @author tyoun66
 */
public class BirthDayCake extends Cake{
    public String firstName;
    public int age;
    public BirthDayCake(String Flav, int Tier, double Price, String First, int Age) {
        super(Flav, Tier, Price);
        firstName = First;
        age = Age;
    }
    @Override
    public void printCard() {
        System.out.printf("\nHappy Birthday to %s! You just turned %d :)", firstName, age);
        super.printCard();
    }
    
    
}
