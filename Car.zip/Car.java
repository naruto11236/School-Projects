/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package carsproject;

/**
 * Tyler Young
 * 5:57
 * @author tyoun66
 */
public class Car {
    long vinNum = 0;
    String model = "";
    int year = 0;
    double mileage = 0;
    public Car() {   
    }
    public Car(long vinNumber, int yearOfCar, String modOfCar) {   
        vinNum = vinNumber;
        model = modOfCar;
        year = yearOfCar;
        
        
    }
    public void setMileage(double miles) {
        mileage = miles;
    }
    public String getInfo() {
       return String.format("%d %s (VIN: %d, mileage: %.1f miles",year, model,vinNum,mileage); 
    }
    public static void main(String[] args) {
        Car c1 = new Car(12313131, 2009, "Camry");
        c1.setMileage(60000);
        System.out.println(c1.getInfo());
        Car c2 = new Car(95645421,2010, "Accord");
        c2.setMileage(95000);
        System.out.println(c2.getInfo());
        
        Car c3 = new Car(45746587, 2019, "CX5");
        c3.setMileage(600);
        System.out.println(c3.getInfo());
                
    }
    }
    
    

