/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ShelterProject;

/**
 *Tyler Young
 * @author tyoun66
 */
public class Animal implements Comparable<Animal> 
{
    private String name = "";
    private String kind = "";
    private double ageMonths = 0;
    public Animal(String Name, String Kind, double Age) 
    {
        name = Name;
        kind = Kind;
        ageMonths = Age;
    }
    public void printInfo() {
        if(ageMonths<1) {
            ageMonths = ageMonths * 12;
            String s = ageMonths + " months";
        System.out.printf("%-10s%-10s %-5s\n", kind, s, name);
        }
        else
        { 
            
            System.out.printf("%-10s%-9s %-5s\n", kind, Double.toString(ageMonths) +" years", name);
            
        }
    }
    
    public String getName()
    {
        return name;
    }
    public String getKind()
    {
        return kind;
    }
    public double getAgeMonths()
    {
        return ageMonths;
    }
    
    @Override
    public int compareTo(Animal o) {
        if(this.getKind().compareTo(o.getKind())!=0) {
            return this.getKind().compareTo(o.getKind());
            
        }
        else if(this.getKind().compareTo(o.getKind())==0) {
            if(Double.compare(this.getAgeMonths(), o.getAgeMonths()) != 0) {
                return Double.compare(this.getAgeMonths(), o.getAgeMonths())*-1;
            }
            else if(Double.compare(this.getAgeMonths(), o.getAgeMonths()) == 0) {
                if(this.getName().compareTo(o.getName())!=0) {
                    return this.getName().compareTo(o.getName());
                }
            }
        }
        return 0;
    }
    
    public static void main(String [] args) {
       
        Animal Tyler = new Animal("Tyler", "dog", 13.0);
        Tyler.printInfo();
    }


    }

