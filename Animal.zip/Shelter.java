/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ShelterProject;
import java.util.*;
/**
 *
 * @author tyoun66
 */
public class Shelter {
    String shelterName = "";
    List <Animal> animals = new ArrayList<Animal>();
    public Shelter(String ShelterName) {
            shelterName = ShelterName;
        }
    public void addAnimal(Animal animalToAdd) {
        animals.add(animalToAdd);
    }
    public void listAnimals() {
        Collections.sort(animals);
        System.out.printf("Welcome to Pet Haven Shelter\n===================================\n%-10s%-10s%-10s\n-----------------------------------\n", "Kind","Age","Name");
        for(Animal a: animals) {
            a.printInfo();
        }
        
    }
    public static void main (String [] args) {
        Shelter shltr = new Shelter("Pet Haven");
        
        shltr.addAnimal(new Animal("Muffins", "Dog", 13));
        shltr.addAnimal(new Animal("Charlie", "Cat", 1.5));
        shltr.addAnimal(new Animal("Spot", "Rabbit", 3.5));
        shltr.addAnimal(new Animal("Dexter", "Rabbit", 0.75));
        shltr.addAnimal(new Animal("Bluex", "Dog", 0.5));
        
        shltr.listAnimals();
    }
}
